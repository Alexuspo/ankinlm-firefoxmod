# Privacy Policy for AnkiNLM

AnkiNLM does not collect, store, or share any personal information from users.

The extension runs entirely on the user's local browser and only interacts with the NotebookLM page to extract flashcard data already available in the current session. No data is transmitted to any external server.

**Collected Data:** None  
**Shared Data:** None  
**Cookies or Analytics:** None  
**Third-party Services:** None

If you have any questions about this privacy policy, please contact the developer through the GitHub repository:  
[https://github.com/maialks/ankinlm](https://github.com/maialks/ankinlm)

